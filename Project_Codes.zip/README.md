# or-sim
Simulation of Osiris Rex Mission

Open and run 'project.m' file. All other files are supporting functions that are called from within that file.
